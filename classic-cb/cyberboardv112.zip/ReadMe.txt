                   ----------------------------
                     CyberBoard Release Notes
                   ----------------------------
                          Dale L. Larson
                          June 29, 2001
                   ----------------------------


Version 1.12 Release
====================

New features for CBPlay.exe:
----------------------------

- A different style of cursor is displayed when you are 
  recording a compound move. 

Bug fixes:
----------

- CBPlay.exe - The die roller now supports 100 faces on a die. 

- CBPlay.exe - The cell visibility setting of a playing board 
  is imported from the GameBox when adding new boards in the 
  Scenario designer. 

- CBPlay.exe - The auto-stack feature now properly saves and 
  restores negative offsets. 

- CBDesign.exe - The rotate tile option of the main menu no 
  longer disables forever if the project window is selected. 

- Tiles in board cells that use the transparent color for the 
  small image now work properly. 

- Various other small bugs. 


Version 1.10 Release
====================

- New icons for files and programs. These were done by Pokke 
  (the same fellow who did the CyberBoard logos on the Web 
  page). They are much nicer than my artistically challenged 
  hacks.�Sorry for the delay in getting these out Pokke!

- If the folder that contains CyberBoard is tagged as a system 
  file then a nice CyberBoard icon will show up in the Windows 
  file explorer for that folder. The batch file "CBIcon.bat" will 
  do this for you.

New features for CBDesign.exe:
------------------------------

- Keyboard nudging of graphical objects within the board editor. 
  Note that this is the *FIRST* 3rd party programmed feature addition 
  for CyberBoard. It was programmed by Donald McLean. Thanks Donald! 
  A very cool feature. Here is the key list:

  - Arrow (up, down, left, right) nudge selected components 1 
    pixel (or 1 grid width/length if grid turned on).
  - Shift-arrow scroll window.
  - Control-arrow nudge and scroll.
  - Alt-arrow nudge 5 pixels (or 5 grid widths/lengths).
  - Alt-Shift-Arrow fast scroll.
  - Alt-Control-Arrow fast nudge/scroll.
  - Page scroll window one page up or down.
  - Control-Page (up, down) scroll window one page left or right.
  - Home top of board.
  - End bottom of board.
  - Control-Home far left of board.
  - Control-End far right of board.

- The cell layer now supports tiles that have transparent regions. 
  For backward compatibility this feature is off by default. To enable 
  it for a playing board check "Enable transparent tiles in cells" 
  in the Board Properties Dialog.

- You can now clone a playing board by right-clicking on the board 
  name in the project window and selecting the "Clone Selected Board" 
  command.

- The tile selection pane in the bitmap editor now supports scrolling so 
  you can select different tiles even when the full scale tile is really 
  large.

New features for CBPlay.exe:
----------------------------

- The main playing area can now be split vertically and horizontally. 
  Each board view can be zoomed and scrolled independently. To use the 
  feature select the Window menu or right click on a board view.

- The select list and tiny board view can now be hidden. To hide them, 
  uncheck "Show select list and tiny board view." in the Board Properties 
  Dialog.

- The Scenario designer now supports automatically creating piece trays 
  from the piece groupings defined in the gamebox file. See the command 
  "Create Trays from Piece Groups..." on the "Project" menu.

- The die roller now supports rolling multiple sets of the specified roll. 
  For instance, you could roll 50 2D6's at a time (if you're so inclined).

- The message view dialog now displays the entire history of messages 
  that have been viewed during playback.

- The message entry dialog now displays the entire history of messages 
  that have been entered during the current recording.

- A message can now be recorded without closing the send message dialog.

- If the pop-up map is too large for the screen it will be scaled down 
  so all of it is visible.

- If you chose to discard a compound move, you are now prompted to 
  verify your decision. This is to prevent accidental loss of moves.

- The delay between submoves of a compound move has been increased.


Bug fixes:
----------

- CBDesign.exe - If you used the "Apply Cell Mask" feature in the tile 
  editor and cancelled the dialog the program would crash. This 
  embarrassing bug is now fixed.

- CBPlay.exe - Importing move files that contain no moves will no 
  longer enable the move stepping buttons. These buttons would cause the 
  program to crash if used.

- CBPlay.exe - names in marker tray are now alpha sorted.

- CBPlay.exe - Tiles that are greater than 255 pixels in height are now 
  truncated properly in lists. Note that due to a limitation in Windows 
  listboxes items larger than 255 pixels are not possible.

- CBPlay.exe - If the board cell grid is set to use very large cells in 
  messes up the auto-scroll code. This is now fixed.


Version 1.02 Release
====================

Bug fixes:
----------

- CBPlay.exe. The random number generator used for die rolls has 
  been completely overhauled.

- CBPlay.exe. Sort the tray name combo in the tray palettes by name. 
  Also doubled the length of the combo box's drop down list.

- CBPlay.exe. Fixed rare crash that occurred when merging move files 
  with a new game created from a modified scenario. It occurred when 
  the "Use move game state is selected" option was used.

- CBPlay.exe. Hitting the Close History button while moves were in 
  mid-playback caused the program to crash.

- CBDesign. If tiles are deleted that aren't being used anywhere 
  in the GameBox, don't consider it a major revision. This prevents 
  messages about the GameBox file being newer than the game file when 
  the file really is OK for play.

- CBDesign.exe. When drawing on tile bitmap images with a zero width 
  pen nothing was rendered. Now the pen is assumed to be one pixel.

New features for CBPlay.exe:
----------------------------

- The key "F9" toggles playing piece visibility. This is handy for 
  a quick check of the underlying hexes.

- The key "F10" toggles between showing move indicator lines above the 
  playing pieces or below them.


Version 1.01 Release
====================

Bug fixes:
----------

- CBDesign.exe. Sheesh! I screwed up the File/New command so it crashes 
  the program <blush>. This update fixes it. Many thanks to Luca Saletti 
  for reporting this so quickly!


Version 1.0 Release
===================

Here it finally is...a version no time limits! 

The file format has not changed from the final beta version. Existing 
games and gameboxes will work fine.

Enjoy!

Beta 5.13 Board Editor Update Release Notes
===========================================

Bug fixes: 
----------

CBDesign.exe. Yet another bug exists in Beta 5.12 and earlier versions 
of the designer program that could cause a GameBox file to be damaged 
beyond repair. This is a very rare bug that only rears its ugly head 
on GameBoxes with many tiles of differening dimensions. Almost all 
users of the software will not be affected sinze they only use a 
small set of tile sizes. Those who have been impacted no doubt know 
about it already (as far as I know only one person was affected and 
I managed to repair his GameBox).

Details:

The problem occurs when you hit an internal limit of the program. 
CyberBoard internally stores tiles in bitmaps called tile sheets. 
Tiles that are the same height and width are stored in the same tile 
sheet. If the a tile sheet gets too large I create a new tile sheet. 
CB supports up to 255 of these tile sheets. If you exceed 255 tile 
sheets the problem occurs. I never imagined in the early days of 
CB (in 16 bit Windows) that more than 255 tile sheets would be needed.

To really fix this I need to expand the number of tile sheets internally 
supported (which changes the GameBox file format) but this will produce 
GameBoxes that are not compatible with earlier versions of the 
program. For now, Beta 5.13 expands the allowable size of each tile sheet 
and more efficiently reuses tile sheets that are empty.

Beta 5.12 Board Editor Update Release Notes
===========================================

Bug fixes: 
----------

CBDesign.exe. A bug exists in Beta 5.11 and earlier versions of the 
designer program that could cause a GameBox file to be damaged beyond 
repair. This bug only rears its ugly head on VERY large GameBoxes. Almost 
all users of the software will not be affected. Those who have been 
impacted no doubt know about it already. This is a good news / bad news 
fix:

The Good News

The bug is fixed. This bug has been in the program since its first 
release. Basically CB tries to keep the size of internal bitmaps 
(internally dubbed "tile sheets") smaller than 4096 pixels high. A 
tile sheet contains tiles that are all the same height and width. The 
code that checks if a new tile sheet should be created was not working 
properly. The result: bitmaps that can be much taller than 4096 pixels. 
GameBoxes that have exceeded this limit are OK until they 
exceed 65535 pixels--a very unlikely event.

The Bad News

Any gameboxes that have tile sheets larger than 65535 pixels high are 
damaged for good. A rare occurrence but can happen. Tile sheets that 
are larger than 4096 but less than 65535 will still work fine. 
A thousand apologies for any trouble this may have caused some folks.

Beta 5.11 Release Notes
=======================

This release was primarily made to provide a new date for the program's 
"Time-Bomb".

Bug fixes: 
----------

- CBPlay.exe. If you used the window close button (X) of the message reading 
  dialog, no other messages in the playback could be read.

- Both programs. Cyberboard files types are no longer available on the 
  Windows "New" menu (normally seen by right clicking in the Windows 
  Explorer). CyberBoard doesn't support this feature.

- CBPlay.exe. Two sided playing pieces using different sized tiles on each 
  side didn't properly repaint when flipped over.

- CBPlay.exe. When changing a playing board's zoom level CyberBoard now 
  tries to maintain the center of the view (if possible). This should give 
  more consistant results when zooming in and out.

New features for CBPlay.exe
-----------------------------

- There is a new board properties option called "Automatically Show 
  Board on Open". If this is checked, the board will automatically be 
  viewed when you open that Game or Scenario file. (Happy Bart?) 

Beta 5.10 Release Notes
=======================

Bug fixes: 
----------

- CBDesign.exe. Fixed a bug in the PolyGon drawing tool that 
  made it impossible to draw right and bottom areas of a 
  board. I accidentally introduced this bug in Beta 5.08. 
  Sorry about that!

- CBPlay.exe. The popup mini-board now can be dismissed without 
  affecting the main board. Either hit the ESC key or click off 
  of the mini-board window.

New features for CBDesign.exe
-----------------------------

- The polygon board drawing tool functionality has been extended
  to allow "free-hand" drawing. Just hold the mouse button down 
  and scribble.

- A new color changer tool has been added to the tile editor. It 
  works just like the paint bucket (flood fill) tool except that 
  all colors in the bitmap that match the clicked color are changed 
  to the new color.

New features for CBPlay.exe
-----------------------------

- An "Indicators on Top" command has been added to the "View" 
  menu. Indicators are the lines and boxes that indicate piece 
  movement during playback. 

- A "Single Step Compound Moves" command has been added to the
  "Playback" menu. This command allows you to step through a 
  compound move to see every piece of it.

Beta 5.08 Release Notes
=======================

Bug fixes: 
----------

- Fixed a NASTY crash bug in CBDesign.exe. The crash was most likely 
  to occur if a session of program use was very long and you were doing 
  a lot of bitmap editing (copies, pastes, etc.). Basically the program 
  was leaking bitmap resources. When you close the program the resources 
  were reclaimed. In rare cases you could cause Win95 to operate 
  strangely since it would get resource starved. This problem wouldn't 
  show itself on Windows NT since NT essentially provides an "unlimited" 
  amount of resources. This is why I never saw it--I do my program 
  development in Windows NT. A special thanks goes out to Tim Cropley 
  who reported the crash problem and worked tirelessly with me to nail 
  it. He gave very good bug reports that helped me narrow the problem 
  down. THANKS TIM!

Beta 5.06 Release Notes
=======================

Bug fixes
---------

- Send message dialog. If you type text after rolling dice, that text 
  wasn't recorded.

- Die roller security hole. It has been pointed out to me (thanks Paul!)
  that a person could simply type in text that looks like a die roll 
  to get the results they want. Duh. I'll admit it never occurred to 
  me. To prevent this, all lines of text produced by the die roller 
  now have a chevron character (�) prefixing them. The editable areas 
  of the send message dialog no longer allow this character to be typed 
  or pasted into a message.

Beta 5.05 Release Notes
=======================

Bug fixes
---------

- The die roller was only rolling D6's. I'm very sorry for that one!

Beta 5.04 Release Notes
=======================

New features for CBDesign.exe
-----------------------------

- None.

New features for CBPlay.exe
-----------------------------

- Die Roller. Yep...you heard right. I guess I can be induced 
  to do something if I get hit in the head enough!

  The die roller is integrated into the message send dialog. When you 
  roll dice the message edit area is converted into a read-only part 
  and an editable part. The results of the roll as well as any 
  message text typed thus far are transferred into the read-only area 
  to discourage "adjustments" to the results. Also the ability to 
  discard the message is thereafter disabled. If the roll had a problem 
  the player would need to inform the opponent via the message edit area.

- A quick navigation feature has been added to the tiny overview map. If
  you right click on the tiny map you'll get a pop up version of it that
  you can click on to quickly jump about in the main map window.

- Playback truncation. You can now discard the trailing parts of a move 
  playback. To use this, step to the place in the playback that you want
  to use as the new starting position of the game and select menu command
  "Playback/Accept Move File Playback...". You will be presented with
  a dialog that gives you the option of discarding the remainder of
  the moves.

  Truncating the move file playback is useful for recovering
  from a hopelessly flawed set of moves. You would resume play at 
  the state of the game where the playback was truncated.

- When you are playing back a move file, the title and description of the
  file are now associated with the <Move File Playback> line of the
  project window.

- You can now save a bitmap image of a playing board directly into
  a disk file.

- There is now a menu command that allows you to select all markers that
  were created from a specific marker group. This is useful for only
  deleting a specific class of markers.

  One use for this feature would be to have a marker group that contains
  markers used to indicate a piece has moved. So you would move a piece, mark
  it, move another piece, mark it, and so on. When all your pieces are moved,
  use the menu command "Select All Markers From >" and pick the group that
  has the "moved piece" markers and hit the delete key.

Bug fixes
---------
- F1 key now pops up the Help file.

- Using a "net" selection rectangle that clicks on the lower right
  and drags to the upper left now works properly.

- A weird bug related to exporting game history records to a move
  file has been corrected. For the few people it impacted the bug gave
  the appearance of saving a previous move recording.

- Some problems with the snap grid which occurred when dragging
  multiple pieces have been corrected.

- Other little nits...here and there.

Beta 5.01 Release Notes
=======================

Bug fixes
---------
- Problem with snap grid when dragging multiple selected pieces. 
  Now uses the piece clicked on for snap grid reference.

- Loading history record caused complaint about a missing playing 
  board. If you get this message the game file is probably 
  corrupted. Save the game file as a scenario and work from there. 
  Problem is caused by too much text in the scenario description.

- In half size board scale drags left artifacts if half piece 
  size was odd number of pixels.

- New Scenarios now inherit the snap grid settings from the 
  GameBox.

- When pieces are moved around on the playing board they now
  remain selected.

Beta 5 Release Notes
====================

This beta of CyberBoard contains all the features that will
be in the final release. I don't intend to add any more major 
features before the first unrestricted version is posted.

New features for CBDesign.exe
-----------------------------

- Context menus have been added to the right mouse button for 
  most of the windows in the program. 

- You can now edit existing text fields on the map window by 
  selecting and double-clicking them. 

- You can now copy an existing drawing layer bitmap to the clipboard. 
  Just select the bitmap on one of the playing board drawing layers 
  and use the Edit/Copy menu command. 

- ToolTips have been added to the color picker window to 
  clarify its use. 

- The board creation dialog now displays pixel dimensions of 
  a candidate board.

- Some small bugs.

New features for CBPlay.exe
---------------------------

- Context menus have been added to the right mouse button for most 
  of the windows in the program. 

- A new way of specifying moves called Compound Moves has been 
  added. Compound moves allow you group an arbitrary sequence of 
  single moves so they are played back as a single animated 
  sequence of moves. For example, you could move a piece, rotate 
  it and move it again as a single compound move. Upon playback your 
  opponent will see the move as a single animated sequence. The 
  Actions menu has the new commands for compound moves. 

- A new way to rotate playing pieces called Incremental Rotation 
  has been added. Incremental rotation is done directly on the 
  board so you can see the exact piece facing before committing to 
  it. To do this, select a piece and use the 
  "Actions/Rotate Piece - Incremental" menu command. You'll be 
  presented with a popup window that you can use to rotate the 
  piece either clockwise or counter-clockwise. 

- You can now step backwards through the moves during playback. 
  When you step back a move you'll see a replay of the previous 
  move.

- The small overview map can be used to jump around on the main map 
  view. The main view is centered on wherever you click the mouse 
  in the small map.

- You can now save the current state of game play as a scenario file.

- Some small bugs.

Beta 4 Release Notes
====================

New features for CBDesign.exe
-----------------------------

- You may now toggle whether or not the Select tool is 
  automatically reselected after drawing with another tool. 
  The toggle is available under the Project menu.

- You may now change the finger print of a GameBox. The finger 
  print is a unique numeric ID that enables Game files to 
  identify the GameBox they below with. The probable use of 
  this feature is to make a new GameBox based on another GameBox. 
  Once you change the finger print the GameBox will not work 
  with any scenario and game files that were formerly
  associated with them.

- Fixed bug in initial default snap grid values.

- Fixed bug that prevented app from being restored from a 
  minimized state if a palette window was open.

- Some small bugs.

New features for CBPlay.exe
---------------------------

- Fixed a NASTY bug that prevented games history records 
  from being load and replayed in pre-beta3 files. If you 
  double-clicked on a game history record and it didn't work 
  you were victimized by the bug.

- Fixed bug in initial default snap grid values.

- Fixed bug that prevented app from being restored from a 
  minimized state if tray or marker windows were open.

- Some small bugs.

Beta 3 Release Notes
====================

New features for CBDesign.exe
-----------------------------

- You can now save and load tile libraries (file extension 
  gtl). The file format is documented in file GTLFormat.txt 
  so programmer types can create ad-hoc tile generation 
  programs whose output can be directly imported into 
  CyberBoard. 

  To create a tile library select the tiles you wish to save 
  using the project window. Then use menu command Project/Save 
  Tile Library File to specify the filename. To load a tile 
  library select the tile group you wish to load the tiles 
  into (in the project window) and use the menu command 
  Project/Load Tile Library File.

- You can now specify fractions of a pixel when setting up snap 
  grids. 

- Various adjustments to the menus.

- Bug Fixes.

New features for CBPlay.exe
---------------------------

- You can now save a bitmap image of the current game board into a 
  bitmap file.

- You can now specify fractions of a pixel when setting up snap 
  grids.

- Various adjustments to the menus.

- Bug Fixes.

Beta 2 Release Notes
====================

New features for CBDesign.exe
-----------------------------

- When working with Tiles in the project window you may
  now select more than one in the list box.

- You can now copy tiles (Ctrl+C) selected in the tile list
  shown in the project window onto the clipboard. You may 
  then paste (Ctrl+V) them into tile sets in any GameBox.

- You can now rearrange tiles in the tile window by using the 
  mouse to drag and drop them.

- You can now move tiles from one tileset to another by using the 
  clipboard. To do this: select and copy the tiles you want to
  move to the clipboard (Ctrl+C) using the tile list in the 
  project window. Then select the new tile set and use menu 
  File/Move (Ctrl+M) to move them.

- Added toolbar button for leaving history playback mode.

- The free form drawing layers of the board editor now allow you 
  to paste an arbitrary Windows bitmap from the clipboard or 
  a file directly onto the board. You can then move it around 
  as you would any drawing object.


New features for CBPlay.exe
-----------------------------

- Added menu handling for accepting or discarding a playback of 
  a move file. This was and still is an option available in the 
  project window. It was put on the main menu to make it easier
  to find and more intuitive.

  If the move file is accepted rather than discarded, the moves 
  are entered into the game history log and the final board state 
  (piece locations etc.) are now considered the current state of 
  the game.

- Added ability to copy a bitmap image of a complete game board 
  to the Windows Clipboard. One possible use would be to paste the 
  image into Windows Paint so you could print it.

Beta 1 Release Notes
====================

So here it is. Let me first get the obligatory apologies out of the way...
I'm sorry about the following:

- The help files are lame and out of date. However, there is valuable info 
  in them. Ignore all the stuff about testers etc... My help
  tools are way out of date so I'll probably redo the documentation
  (such that it is) as HTML.

- The way the project windows work for the various types of CyberBoard
  documents (ie, Game Boxes, Scenarios, and Games) can be confusing. They're
  going to be simplified a bit. The underlying functionality
  won't change though.

- No Dice rolling support. Yeah I know...I just never got around to it.
  Soon...Soon...

- Pretty much no mouse right click support yet. This drives me nuts and
  I'll probably add that real soon!

- Finally...the icons are something I tossed together and they certainly
  reflect that!

I'm sure there are little bugs and oversights here and there. All-in-all
it should be pretty usable once you get used to some of the user interface
quirkiness.


Program Features
----------------

- Emulates real life game components (boards, pieces, markers...).
  GameBox files hold the boards, pieces, markers etc. Scenario files
  contain the starting situation of a particular game. Game files
  hold the current state of a game as well as it's entire history of play.

- A game designer program is used to actually design the components of a game.

- A game player program is used to create scenarios and actually play the 
  PBEM game.

Game Designer Program Features:

- Graphical bitmap editor for manipulating tiles. A global transparent
  color can be defined to allow non-rectangular tiles.

- Free form graphics editor for drawing lines, rectangles, ellipses, and
  polygons.

- Each board has three sizes: full scale, half scale and small scale.

- Board editing is done on three drawing layers: A grid layer is wedged
  between two free form drawing layers.

- Create two sided playing pieces.

- Create graphical marker tiles for marking various things during game play.

- Boards can use Hex grids (two varieties), brick grids, and rectangular
  grids. The grid lines can be hidden.

- Snap grids.

- Other stuff I can't remember right now.

Game Player Program Features:

- A scenario designer allows you to layout the starting positions of a game
  and also allows you to define what game boards and playing pieces are to 
  be used. The pieces that are in play are placed in trays or on a board.
  Trays are defined in the scenarios. All game play start with a Scenario
  file.

- Moves are exchanged in a small recorded move file so they can be EMailed
  to your opponents.

- Auto stacking of pieces.

- Flipping two sided pieces.

- Rotation of playing pieces for indicating facings.

- Two playing piece tray windows.

- A single marker window used to gain access to graphical markers.

- Allows plotted moves so your opponents can see exactly the path taken 
  when you moved your pieces.

- Text messages can be sent any time while you're recording your moves.

- Maintains entire history of a game.

- Probably lots of other stuff I can't recall right now.


Distributed Files
-----------------

The various files in found in this directory:

ReadMe.txt    -- This file.

CBDesign.exe  -- This program is used to design the game boards, playing
                 pieces, markers, etc... Contains many tools for editing
                 bitmapped tiles, drawing shapes and so on.

CBPlay.exe    -- This program is used to create game scenarios and
                 actually play games.

CBoard.hlp    -- The help file for both programs. Very sparse.

Tactics2.hlp  -- The help file for a Tactics 2 GameBox I created. Although
                 I can't provide the actual game, the help file might
                 provide additional insights into the system.

Generic.gbx   -- A generic wargame with chits on a hex board.

Generic.gsn   -- A scenario for the generic wargame.

GenericGame.gam -- A demo of a game created from the Generic scenario.

SuperCheckers.gbx
SuperCheckers.gsn -- The Game Box and Scenario for super checkers. I did this
                     to prove to a friend I could design the board in under
                     15 minutes (and I did!). Not very pretty but it works!


Getting Started
---------------

The best way to get a feel for the system would probably be to replay
a game. To do this:

1) Launch CBPlay.exe
2) Open file GenericGame.gam
3) Double click on the first entry under the History section
   of the game's project window. 
4) Use the "VCR" buttons to step through the game. When you get to the
   end of the current history record (the next move button disables),
   press the Next History button. (>>)
5) When you're all done use the menu selection: Playback/Close 
   History Playback.


Reporting Bugs
--------------

Email any bugs you find to dlarson@norsesoft.com. 


Asking Questions About CyberBoard 
---------------------------------

To avoid getting bogged down with personal mail regarding CyberBoard I won't
answer questions sent this way. Please post any questions to the CyberBoardML
mailing list on eGroups.com:

http://www.egroups.com/subscribe/CyberboardML

Thanks!

Dale Larson
http://www.norsesoft.com/cyberboard.html
dlarson@norsesoft.com
