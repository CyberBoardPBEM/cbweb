                   ----------------------------
                     CyberBoard Release Notes
                   ----------------------------
                          Dale L. Larson
                        September 5, 2001
                   ----------------------------

For version specific details regarding this release see the
"Release History" section in the CyberBoard help file (CBOARD.CHM)

Distributed Files
-----------------

The various files in found in this directory:

ReadMe.txt    -- This file.

CBDesign.exe  -- This program is used to design the game boards, playing
                 pieces, markers, etc... Contains many tools for editing
                 bitmapped tiles, drawing shapes and so on.

CBPlay.exe    -- This program is used to create game scenarios and
                 actually play games.

CBoard.chm    -- The HTML help file for both programs.

Generic.gbx   -- A generic wargame with chits on a hex board.

Generic.gsn   -- A scenario for the generic wargame.

GenericGame.gam -- A demo of a game created from the Generic scenario.

CBIcon.bat
desktop.ini   -- Run CBIcon.bat from the installed directory to change the
                 folder icon into the CyberBoard icon.


Getting Started
---------------

The best way to get a feel for the system would probably be to replay
a game. To do this:

1) Launch CBPlay.exe
2) Open file GenericGame.gam
3) Double click on the first entry under the History section
   of the game's project window. 
4) Use the "VCR" buttons to step through the game. When you get to the
   end of the current history record (the next move button disables),
   press the Next History button. (>>)
5) When you're all done use the menu selection: Playback/Close 
   History Playback.


Reporting Bugs
--------------

Email any bugs you find to dlarson@norsesoft.com. 


Asking Questions About CyberBoard 
---------------------------------

To avoid getting bogged down with personal mail regarding CyberBoard I won't
answer questions sent this way. Please post any questions to the CyberBoardML
mailing list on groups.yahoo.com:

http://groups.yahoo.com/group/CyberboardML

Thanks!

Dale Larson
http://www.norsesoft.com/cyberboard.html
dlarson@norsesoft.com
